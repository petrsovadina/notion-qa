# Rozsah problému

Created: July 3, 2023 8:33 AM

<aside>
☝ Use the slash command to add images, bullet points, and even Figma prototypes — whatever illustrates your points best!

</aside>